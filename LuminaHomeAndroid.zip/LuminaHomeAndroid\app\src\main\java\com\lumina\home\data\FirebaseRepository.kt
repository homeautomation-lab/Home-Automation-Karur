package com.lumina.home.data

import com.google.firebase.database.DataSnapshot
import com.google.firebase.database.DatabaseError
import com.google.firebase.database.FirebaseDatabase
import com.google.firebase.database.ValueEventListener
import kotlinx.coroutines.channels.awaitClose
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.callbackFlow
import kotlinx.coroutines.tasks.await

class FirebaseRepository {
    private val db = FirebaseDatabase.getInstance()

    fun controlValuesFlow(): Flow<Map<String, Any?>> = callbackFlow {
        val values = mutableMapOf<String, Any?>()
        val listeners = mutableListOf<Pair<com.google.firebase.database.DatabaseReference, ValueEventListener>>()

        DbPaths.controlRoots.forEach { root ->
            val ref = db.getReference(root)
            val listener = object : ValueEventListener {
                override fun onDataChange(snapshot: DataSnapshot) {
                    snapshot.children.forEach { child ->
                        values[DbPaths.refPath(root, child.key ?: return@forEach)] = child.value
                    }
                    trySend(values.toMap())
                }

                override fun onCancelled(error: DatabaseError) {
                    close(error.toException())
                }
            }
            ref.addValueEventListener(listener)
            listeners += ref to listener
        }

        awaitClose {
            listeners.forEach { (ref, l) -> ref.removeEventListener(l) }
        }
    }

    fun layoutFlow(): Flow<Map<String, Any?>?> = callbackFlow {
        val ref = db.getReference(DbPaths.LAYOUT_ROOT)
        val listener = object : ValueEventListener {
            override fun onDataChange(snapshot: DataSnapshot) {
                @Suppress("UNCHECKED_CAST")
                trySend(snapshot.value as? Map<String, Any?>)
            }

            override fun onCancelled(error: DatabaseError) {
                close(error.toException())
            }
        }
        ref.addValueEventListener(listener)
        awaitClose { ref.removeEventListener(listener) }
    }

    suspend fun setValue(path: String, value: Any?) {
        db.getReference(path).setValue(value).await()
    }

    suspend fun setToggle(root: String, key: String, current: Any?) {
        setValue(DbPaths.refPath(root, key), FirebaseValueUtils.nextToggleValue(current))
    }

    suspend fun setPush(root: String, key: String, active: Boolean) {
        setValue(DbPaths.refPath(root, key), if (active) "1" else "0")
    }

    suspend fun ensurePushKey(baseKey: String) {
        val root = DbPaths.rootForKey(baseKey) ?: return
        val pushKey = DbPaths.pushKeyFor(baseKey)
        val path = DbPaths.refPath(root, pushKey)
        val snap = db.getReference(path).get().await()
        if (!snap.exists()) setValue(path, "0")
    }

    suspend fun saveLayout(layoutMap: Map<String, Any?>) {
        db.getReference(DbPaths.LAYOUT_ROOT).setValue(layoutMap).await()
    }
}
