package com.lumina.home

import android.app.Application
import com.google.firebase.database.FirebaseDatabase

class LuminaApp : Application() {
    override fun onCreate() {
        super.onCreate()
        FirebaseDatabase.getInstance().setPersistenceEnabled(true)
    }
}
