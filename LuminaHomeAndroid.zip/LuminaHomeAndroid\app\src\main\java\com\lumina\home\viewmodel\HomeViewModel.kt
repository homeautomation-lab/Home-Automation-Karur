package com.lumina.home.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.viewModelScope
import com.lumina.home.data.DbPaths
import com.lumina.home.data.FirebaseCatalog
import com.lumina.home.data.FirebaseRepository
import com.lumina.home.data.FirebaseValueUtils
import com.lumina.home.data.LayoutStore
import com.lumina.home.data.TimePickerUtils
import com.lumina.home.data.model.DeviceRowUi
import com.lumina.home.data.model.HomeLayout
import com.lumina.home.data.model.RoomCardUi
import com.lumina.home.data.model.ZoneSection
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.launch

class HomeViewModel(application: Application) : AndroidViewModel(application) {
    private val repo = FirebaseRepository()
    private val context = application.applicationContext

    private val _connected = MutableLiveData(false)
    val connected: LiveData<Boolean> = _connected

    private val _error = MutableLiveData<String?>(null)
    val error: LiveData<String?> = _error

    private val _toast = MutableLiveData<String?>(null)
    val toast: LiveData<String?> = _toast

    private val _layoutSync = MutableLiveData<String?>(null)
    val layoutSync: LiveData<String?> = _layoutSync

    private val _layout = MutableLiveData(LayoutStore.loadLocal(context))
    val layout: LiveData<HomeLayout> = _layout

    private val _values = MutableLiveData<Map<String, Any?>>(emptyMap())
    val values: LiveData<Map<String, Any?>> = _values

    private val _zones = MutableLiveData<List<ZoneSection>>(emptyList())
    val zones: LiveData<List<ZoneSection>> = _zones

    private val _activeSummary = MutableLiveData("0 / 0 active")
    val activeSummary: LiveData<String> = _activeSummary

    private val _roomDevices = MutableLiveData<List<DeviceRowUi>>(emptyList())
    val roomDevices: LiveData<List<DeviceRowUi>> = _roomDevices

    private val _roomTitle = MutableLiveData("")
    val roomTitle: LiveData<String> = _roomTitle

    private var saveLayoutJob: Job? = null
    private var ignoreRemoteUntil = 0L
    private var currentRoomType: String? = null
    private var currentRoomId: String? = null

    init {
        viewModelScope.launch {
            repo.controlValuesFlow()
                .catch { e -> _error.postValue(e.message) }
                .collect { map ->
                    _values.postValue(map)
                    _connected.postValue(true)
                    rebuildZones()
                    rebuildRoomDevices()
                    updateSummary(map)
                }
        }

        viewModelScope.launch {
            repo.layoutFlow()
                .catch { e ->
                    _error.postValue(e.message)
                    _layout.postValue(LayoutStore.loadLocal(context))
                    rebuildZones()
                }
                .collect { remote ->
                    if (System.currentTimeMillis() < ignoreRemoteUntil) return@collect
                    val normalized = if (remote != null &&
                        (remote.containsKey("switchRooms") ||
                            remote.containsKey("motorRooms") ||
                            remote.containsKey("alarmRooms"))
                    ) {
                        LayoutStore.normalizeLayout(remote)
                    } else {
                        val local = LayoutStore.loadLocal(context)
                        persistLayout(local, immediate = true)
                        local
                    }
                    _layout.postValue(normalized)
                    LayoutStore.saveLocal(context, normalized)
                    rebuildZones()
                    rebuildRoomDevices()
                }
        }
    }

    fun clearToast() = _toast.postValue(null)

    fun showToast(msg: String) = _toast.postValue(msg)

    fun persistLayout(layout: HomeLayout, immediate: Boolean = false) {
        LayoutStore.saveLocal(context, layout)
        _layout.postValue(layout)
        ignoreRemoteUntil = System.currentTimeMillis() + 900
        _layoutSync.postValue("saving")
        saveLayoutJob?.cancel()
        saveLayoutJob = viewModelScope.launch {
            if (!immediate) delay(350)
            try {
                repo.saveLayout(LayoutStore.toFirebaseMap(layout))
                _layoutSync.postValue("saved")
                delay(2000)
                _layoutSync.postValue(null)
            } catch (e: Exception) {
                _layoutSync.postValue("error")
                _toast.postValue("Could not save layout — check Firebase rules for HOME_CONSOLE_LAYOUT")
            }
        }
    }

    fun openRoom(roomType: String, roomId: String) {
        currentRoomType = roomType
        currentRoomId = roomId
        val room = LayoutStore.findRoom(_layout.value ?: return, roomType, roomId)
        _roomTitle.postValue(room?.name ?: "")
        rebuildRoomDevices()
        viewModelScope.launch {
            room?.devices?.filter { FirebaseCatalog.usesPushControl(it) }?.forEach {
                try {
                    repo.ensurePushKey(it.firebaseKey)
                } catch (e: Exception) {
                    _error.postValue(e.message)
                }
            }
        }
    }

    fun closeRoom() {
        currentRoomType = null
        currentRoomId = null
        _roomDevices.postValue(emptyList())
    }

    fun toggleDevice(root: String, key: String) {
        val path = DbPaths.refPath(root, key)
        val current = _values.value?.get(path)
        viewModelScope.launch {
            try {
                repo.setValue(path, FirebaseValueUtils.nextToggleValue(current))
            } catch (e: Exception) {
                _error.postValue(e.message)
            }
        }
    }

    fun setPush(root: String, key: String, active: Boolean) {
        viewModelScope.launch {
            try {
                repo.setPush(root, key, active)
            } catch (e: Exception) {
                _error.postValue(e.message)
            }
        }
    }

    fun saveTime(path: String, formatted: String) {
        viewModelScope.launch {
            try {
                repo.setValue(path, formatted)
            } catch (e: Exception) {
                _error.postValue(e.message)
            }
        }
    }

    fun clearTime(path: String) {
        viewModelScope.launch {
            try {
                repo.setValue(path, "")
            } catch (e: Exception) {
                _error.postValue(e.message)
            }
        }
    }

    fun addRoom(roomType: String, name: String): String? {
        val layout = _layout.value ?: return "Layout not ready"
        val (room, err) = LayoutStore.addRoom(layout, roomType, name)
        if (err != null) return err
        persistLayout(layout)
        if (room != null) openRoom(roomType, room.id)
        return null
    }

    fun deleteRoom(roomType: String, roomId: String): String? {
        val layout = _layout.value ?: return "Layout not ready"
        val err = LayoutStore.removeRoom(layout, roomType, roomId)
        if (err != null) return err
        persistLayout(layout)
        closeRoom()
        return null
    }

    fun renameRoom(roomType: String, roomId: String, name: String) {
        val layout = _layout.value ?: return
        LayoutStore.renameRoom(layout, roomType, roomId, name)
        persistLayout(layout)
        if (currentRoomId == roomId) _roomTitle.postValue(name)
    }

    fun renameDevice(roomType: String, roomId: String, key: String, label: String) {
        val layout = _layout.value ?: return
        LayoutStore.renameDevice(layout, roomType, roomId, key, label)
        persistLayout(layout)
        rebuildRoomDevices()
    }

    fun addDevice(roomType: String, roomId: String, key: String, controlMode: String): Boolean {
        val layout = _layout.value ?: return false
        val ok = LayoutStore.addDevice(layout, roomType, roomId, key, controlMode)
        if (!ok) return false
        persistLayout(layout)
        if (controlMode == "push") {
            viewModelScope.launch {
                try {
                    repo.ensurePushKey(key)
                } catch (e: Exception) {
                    _error.postValue(e.message)
                }
            }
        }
        rebuildRoomDevices()
        return true
    }

    fun removeDevice(roomType: String, roomId: String, key: String) {
        val layout = _layout.value ?: return
        LayoutStore.removeDevice(layout, roomType, roomId, key)
        persistLayout(layout)
        rebuildRoomDevices()
    }

    fun availableKeys(roomType: String) =
        LayoutStore.availableKeys(_layout.value ?: LayoutStore.defaultLayout(), roomType)

    private fun rebuildZones() {
        val layout = _layout.value ?: return
        val values = _values.value ?: emptyMap()
        _zones.postValue(
            listOf(
                buildZone("switch", "Control Zones", layout.switchRooms, values),
                buildZone("motor", "Pump Control", layout.motorRooms, values),
                buildZone("alarm", "Alert Zones", layout.alarmRooms, values)
            )
        )
    }

    private fun buildZone(
        roomType: String,
        title: String,
        rooms: List<com.lumina.home.data.model.RoomEntry>,
        values: Map<String, Any?>
    ): ZoneSection {
        val cards = rooms.map { room ->
            val active = LayoutStore.countRoomActive(room, values)
            RoomCardUi(
                roomType = roomType,
                roomId = room.id,
                name = room.name,
                abbr = LayoutStore.roomAbbr(room.name),
                deviceCount = room.devices.size,
                activeCount = active,
                hasActive = active > 0
            )
        }
        return ZoneSection(roomType, title, cards)
    }

    private fun rebuildRoomDevices() {
        val roomType = currentRoomType ?: return
        val roomId = currentRoomId ?: return
        val room = LayoutStore.findRoom(_layout.value ?: return, roomType, roomId) ?: return
        val values = _values.value ?: emptyMap()

        val rows = room.devices.map { device ->
            val meta = FirebaseCatalog.metaForKey(device.firebaseKey)
            val root = meta?.root ?: DbPaths.rootForKey(device.firebaseKey).orEmpty()
            val isPush = FirebaseCatalog.usesPushControl(device)
            val controlKey = if (isPush) DbPaths.pushKeyFor(device.firebaseKey) else device.firebaseKey
            val path = DbPaths.refPath(root, controlKey)
            val (onKey, offKey) = DbPaths.timingPathsFor(device.firebaseKey)
            val onPath = DbPaths.refPath(root, onKey)
            val offPath = DbPaths.refPath(root, offKey)
            DeviceRowUi(
                firebaseKey = device.firebaseKey,
                label = device.label,
                kind = device.kind,
                controlMode = device.controlMode,
                root = root,
                isOn = FirebaseValueUtils.isOn(values[path]),
                isPush = isPush,
                hasSchedule = FirebaseCatalog.hasBuiltInSchedule(device.kind),
                onTimeDisplay = TimePickerUtils.formatTimeDisplay(values[onPath]),
                offTimeDisplay = TimePickerUtils.formatTimeDisplay(values[offPath]),
                onTimePath = onPath,
                offTimePath = offPath
            )
        }
        _roomDevices.postValue(rows)
    }

    private fun updateSummary(values: Map<String, Any?>) {
        val toggles = DbPaths.switchToggles().map { DbPaths.refPath(DbPaths.SWITCH_ROOT, it) } +
            DbPaths.motorToggles().map { DbPaths.refPath(DbPaths.MOTOR_ROOT, it) } +
            DbPaths.alarmToggles().map { DbPaths.refPath(DbPaths.ALARM_ROOT, it) }
        val active = toggles.count { FirebaseValueUtils.isOn(values[it]) }
        _activeSummary.postValue("$active / ${toggles.size} active")
    }
}
