package com.lumina.home.ui.adapter

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import com.lumina.home.data.model.RoomCardUi
import com.lumina.home.data.model.ZoneSection
import com.lumina.home.databinding.ItemRoomCardBinding
import com.lumina.home.databinding.ItemZoneHeaderBinding

sealed class ZoneListItem {
    data class Header(val title: String) : ZoneListItem()
    data class Room(val card: RoomCardUi) : ZoneListItem()
}

class ZoneAdapter(
    private val onRoomClick: (String, String) -> Unit
) : ListAdapter<ZoneListItem, RecyclerView.ViewHolder>(Diff) {

    fun submitZones(zones: List<ZoneSection>) {
        val items = mutableListOf<ZoneListItem>()
        zones.forEach { zone ->
            items += ZoneListItem.Header(zone.title)
            zone.rooms.forEach { items += ZoneListItem.Room(it) }
        }
        submitList(items)
    }

    override fun getItemViewType(position: Int): Int = when (getItem(position)) {
        is ZoneListItem.Header -> 0
        is ZoneListItem.Room -> 1
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): RecyclerView.ViewHolder {
        val inflater = LayoutInflater.from(parent.context)
        return if (viewType == 0) {
            HeaderVH(ItemZoneHeaderBinding.inflate(inflater, parent, false))
        } else {
            RoomVH(ItemRoomCardBinding.inflate(inflater, parent, false), onRoomClick)
        }
    }

    override fun onBindViewHolder(holder: RecyclerView.ViewHolder, position: Int) {
        when (val item = getItem(position)) {
            is ZoneListItem.Header -> (holder as HeaderVH).bind(item.title)
            is ZoneListItem.Room -> (holder as RoomVH).bind(item.card)
        }
    }

    class HeaderVH(private val binding: ItemZoneHeaderBinding) : RecyclerView.ViewHolder(binding.root) {
        fun bind(title: String) {
            binding.zoneTitle.text = title
        }
    }

    class RoomVH(
        private val binding: ItemRoomCardBinding,
        private val onRoomClick: (String, String) -> Unit
    ) : RecyclerView.ViewHolder(binding.root) {
        fun bind(card: RoomCardUi) {
            binding.roomAbbr.text = card.abbr
            binding.roomName.text = card.name
            binding.roomMeta.text = "${card.activeCount} / ${card.deviceCount} active"
            binding.roomCard.isActivated = card.hasActive
            binding.root.setOnClickListener { onRoomClick(card.roomType, card.roomId) }
        }
    }

    private object Diff : DiffUtil.ItemCallback<ZoneListItem>() {
        override fun areItemsTheSame(old: ZoneListItem, new: ZoneListItem): Boolean {
            return when {
                old is ZoneListItem.Header && new is ZoneListItem.Header -> old.title == new.title
                old is ZoneListItem.Room && new is ZoneListItem.Room ->
                    old.card.roomId == new.card.roomId && old.card.roomType == new.card.roomType
                else -> false
            }
        }

        override fun areContentsTheSame(old: ZoneListItem, new: ZoneListItem) = old == new
    }
}
