package com.lumina.home.data

object FirebaseValueUtils {
    private val onValues = setOf("1", "ON", "on", "true", "TRUE", true, 1)

    fun isOn(value: Any?): Boolean {
        if (value == null) return false
        if (onValues.contains(value)) return true
        return onValues.contains(value.toString().trim())
    }

    fun nextToggleValue(current: Any?): String = if (isOn(current)) "0" else "1"
}
