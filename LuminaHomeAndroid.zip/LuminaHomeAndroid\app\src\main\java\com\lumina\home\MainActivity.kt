package com.lumina.home

import android.os.Bundle
import androidx.activity.viewModels
import androidx.appcompat.content.res.AppCompatResources
import androidx.appcompat.app.AppCompatActivity
import androidx.core.splashscreen.SplashScreen.Companion.installSplashScreen
import androidx.navigation.fragment.NavHostFragment
import androidx.navigation.ui.setupWithNavController
import com.lumina.home.databinding.ActivityMainBinding
import com.lumina.home.viewmodel.HomeViewModel

class MainActivity : AppCompatActivity() {
    private lateinit var binding: ActivityMainBinding
    val homeViewModel: HomeViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        installSplashScreen()
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        val navHost = supportFragmentManager
            .findFragmentById(R.id.nav_host) as NavHostFragment
        val navController = navHost.navController
        binding.toolbar.setupWithNavController(navController)

        navController.addOnDestinationChangedListener { _, destination, _ ->
            binding.toolbar.title = when (destination.id) {
                R.id.homeFragment -> getString(R.string.app_name)
                R.id.roomFragment -> homeViewModel.roomTitle.value ?: getString(R.string.room)
                else -> getString(R.string.app_name)
            }
            binding.toolbar.navigationIcon = if (destination.id == R.id.roomFragment) {
                AppCompatResources.getDrawable(
                    this,
                    androidx.appcompat.R.drawable.abc_ic_ab_back_material
                )
            } else {
                null
            }
            binding.toolbar.setNavigationOnClickListener {
                if (destination.id == R.id.roomFragment) {
                    homeViewModel.closeRoom()
                    navController.popBackStack()
                }
            }
        }
    }
}
