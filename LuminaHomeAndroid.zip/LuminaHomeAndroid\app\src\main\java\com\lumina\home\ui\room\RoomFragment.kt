package com.lumina.home.ui.room

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ArrayAdapter
import androidx.appcompat.app.AlertDialog
import androidx.fragment.app.Fragment
import androidx.fragment.app.activityViewModels
import androidx.navigation.fragment.findNavController
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import com.google.android.material.snackbar.Snackbar
import com.google.android.material.textfield.TextInputEditText
import com.lumina.home.R
import com.lumina.home.data.FirebaseCatalog
import com.lumina.home.data.model.DeviceRowUi
import com.lumina.home.databinding.FragmentRoomBinding
import com.lumina.home.ui.adapter.DeviceAdapter
import com.lumina.home.ui.time.TimePickerDialogFragment
import com.lumina.home.viewmodel.HomeViewModel

class RoomFragment : Fragment(), TimePickerDialogFragment.Listener {
    private var _binding: FragmentRoomBinding? = null
    private val binding get() = _binding!!
    private val vm: HomeViewModel by activityViewModels()
    private lateinit var deviceAdapter: DeviceAdapter
    private var roomType: String = "switch"
    private var roomId: String = ""

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        roomType = arguments?.getString("roomType") ?: "switch"
        roomId = arguments?.getString("roomId") ?: ""
        vm.openRoom(roomType, roomId)
    }

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View {
        _binding = FragmentRoomBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        deviceAdapter = DeviceAdapter(
            onToggle = { root, key -> vm.toggleDevice(root, key) },
            onPush = { root, key, active -> vm.setPush(root, key, active) },
            onTimeClick = { item, isOn -> showTimePicker(item, isOn) },
            onRename = { showRenameDevice(it) },
            onRemove = { confirmRemoveDevice(it) }
        )
        binding.deviceList.adapter = deviceAdapter

        vm.roomTitle.observe(viewLifecycleOwner) { binding.roomTitle.text = it }
        vm.roomDevices.observe(viewLifecycleOwner) { deviceAdapter.submitList(it) }
        vm.toast.observe(viewLifecycleOwner) { msg ->
            msg?.let {
                Snackbar.make(binding.root, it, Snackbar.LENGTH_LONG).show()
                vm.clearToast()
            }
        }

        binding.renameRoomBtn.setOnClickListener { showRenameRoom() }
        binding.deleteRoomBtn.setOnClickListener { confirmDeleteRoom() }
        binding.addDeviceBtn.setOnClickListener { showAddDevice() }
        binding.addRoomBtn.setOnClickListener { showAddRoom() }
    }

    private fun showTimePicker(item: DeviceRowUi, isOn: Boolean) {
        val path = if (isOn) item.onTimePath else item.offTimePath
        val values = vm.values.value
        val raw = values?.get(path)?.toString()
        TimePickerDialogFragment.newInstance(path, item.label, isOn, raw)
            .show(childFragmentManager, "time")
    }

    override fun onTimeSaved(path: String, formatted: String) {
        vm.saveTime(path, formatted)
    }

    override fun onTimeCleared(path: String) {
        vm.clearTime(path)
    }

    private fun showRenameRoom() {
        val input = TextInputEditText(requireContext())
        input.setText(vm.roomTitle.value)
        MaterialAlertDialogBuilder(requireContext())
            .setTitle(R.string.rename_room)
            .setView(input)
            .setPositiveButton(R.string.save) { _, _ ->
                vm.renameRoom(roomType, roomId, input.text?.toString().orEmpty())
            }
            .setNegativeButton(android.R.string.cancel, null)
            .show()
    }

    private fun showRenameDevice(item: DeviceRowUi) {
        val input = TextInputEditText(requireContext())
        input.setText(item.label)
        MaterialAlertDialogBuilder(requireContext())
            .setTitle(R.string.rename_device)
            .setView(input)
            .setPositiveButton(R.string.save) { _, _ ->
                vm.renameDevice(roomType, roomId, item.firebaseKey, input.text?.toString().orEmpty())
            }
            .setNegativeButton(android.R.string.cancel, null)
            .show()
    }

    private fun confirmRemoveDevice(item: DeviceRowUi) {
        MaterialAlertDialogBuilder(requireContext())
            .setMessage(getString(R.string.remove_device_confirm, item.label))
            .setPositiveButton(R.string.remove) { _, _ ->
                vm.removeDevice(roomType, roomId, item.firebaseKey)
            }
            .setNegativeButton(android.R.string.cancel, null)
            .show()
    }

    private fun confirmDeleteRoom() {
        MaterialAlertDialogBuilder(requireContext())
            .setMessage(R.string.delete_room_confirm)
            .setPositiveButton(R.string.remove) { _, _ ->
                val err = vm.deleteRoom(roomType, roomId)
                if (err != null) {
                    vm.showToast(err)
                } else {
                    findNavController().popBackStack()
                }
            }
            .setNegativeButton(android.R.string.cancel, null)
            .show()
    }

    private fun showAddRoom() {
        val input = TextInputEditText(requireContext())
        input.hint = getString(R.string.room_name_hint)
        MaterialAlertDialogBuilder(requireContext())
            .setTitle(R.string.add_room)
            .setView(input)
            .setPositiveButton(R.string.save) { _, _ ->
                val err = vm.addRoom(roomType, input.text?.toString().orEmpty())
                if (err != null) vm.showToast(err)
            }
            .setNegativeButton(android.R.string.cancel, null)
            .show()
    }

    private fun showAddDevice() {
        val available = vm.availableKeys(roomType)
        if (available.isEmpty()) {
            vm.showToast("No devices available to add")
            return
        }
        val names = available.map { "${it.defaultLabel} (${it.key})" }.toTypedArray()
        var selectedIndex = 0
        var controlMode = if (FirebaseCatalog.canChooseControlMode(roomType)) "push" else "toggle"

        MaterialAlertDialogBuilder(requireContext())
            .setTitle(R.string.add_device)
            .setSingleChoiceItems(names, 0) { _, which -> selectedIndex = which }
            .setPositiveButton(R.string.save) { dialog, _ ->
                val key = available[selectedIndex].key
                if (FirebaseCatalog.canChooseControlMode(roomType)) {
                    showControlModePicker(key)
                } else {
                    vm.addDevice(roomType, roomId, key, "toggle")
                }
                dialog.dismiss()
            }
            .setNegativeButton(android.R.string.cancel, null)
            .show()
    }

    private fun showControlModePicker(key: String) {
        val modes = arrayOf("Toggle", "Push (momentary)")
        var selected = 1
        MaterialAlertDialogBuilder(requireContext())
            .setTitle(R.string.control_mode)
            .setSingleChoiceItems(modes, selected) { _, which -> selected = which }
            .setPositiveButton(R.string.save) { _, _ ->
                val mode = if (selected == 0) "toggle" else "push"
                vm.addDevice(roomType, roomId, key, mode)
            }
            .setNegativeButton(android.R.string.cancel, null)
            .show()
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}
