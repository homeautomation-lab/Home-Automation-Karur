package com.lumina.home.data

import android.content.Context
import com.google.gson.Gson
import com.lumina.home.data.model.DeviceEntry
import com.lumina.home.data.model.HomeLayout
import com.lumina.home.data.model.RoomEntry
import com.lumina.home.data.FirebaseCatalog.defaultDisplayLabel
import com.lumina.home.data.FirebaseCatalog.metaForKey
import java.util.UUID

object LayoutStore {
    const val MAX_ROOMS_PER_TYPE = 26
    private const val PREFS = "lumina_prefs"
    private const val LAYOUT_KEY = "lumina-room-layout-v4"
    private val gson = Gson()

    fun defaultLayout() = HomeLayout(
        switchRooms = mutableListOf(RoomEntry("switch-main", "Switches")),
        motorRooms = mutableListOf(RoomEntry("motor-main", "Motors")),
        alarmRooms = mutableListOf(RoomEntry("alarm-security", "Security"))
    )

    fun loadLocal(context: Context): HomeLayout {
        val raw = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            .getString(LAYOUT_KEY, null) ?: return defaultLayout()
        return try {
            normalizeLayout(gson.fromJson(raw, HomeLayout::class.java))
        } catch (_: Exception) {
            defaultLayout()
        }
    }

    fun saveLocal(context: Context, layout: HomeLayout) {
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            .edit()
            .putString(LAYOUT_KEY, gson.toJson(layout))
            .apply()
    }

    @Suppress("UNCHECKED_CAST")
    fun normalizeLayout(data: Any?): HomeLayout {
        val fallback = defaultLayout()
        if (data !is Map<*, *>) return fallback

        fun normRooms(key: String, fb: MutableList<RoomEntry>): MutableList<RoomEntry> {
            val rooms = data[key] as? List<*> ?: return fb
            return rooms.mapNotNull { normalizeRoom(it) }.toMutableList().ifEmpty { fb }
        }

        return HomeLayout(
            switchRooms = normRooms("switchRooms", fallback.switchRooms),
            motorRooms = normRooms("motorRooms", fallback.motorRooms),
            alarmRooms = normRooms("alarmRooms", fallback.alarmRooms)
        )
    }

    private fun normalizeRoom(raw: Any?): RoomEntry? {
        val map = raw as? Map<*, *> ?: return null
        val devices = (map["devices"] as? List<*>)?.mapNotNull { normalizeDevice(it) }?.toMutableList()
            ?: mutableListOf()
        return RoomEntry(
            id = map["id"]?.toString() ?: uid(),
            name = map["name"]?.toString()?.trim().orEmpty().ifEmpty { "Room" },
            devices = devices
        )
    }

    private fun normalizeDevice(raw: Any?): DeviceEntry? {
        val map = raw as? Map<*, *> ?: return null
        val key = map["firebaseKey"]?.toString() ?: return null
        if (isStandaloneAuxKey(key)) return null
        val kind = map["kind"]?.toString() ?: inferKind(key)
        val label = normalizeDeviceLabel(
            map["label"]?.toString(),
            key,
            kind
        )
        val controlMode = normalizeControlMode(map["controlMode"]?.toString(), kind)
        return DeviceEntry(key, label, kind, controlMode)
    }

    private fun normalizeDeviceLabel(label: String?, firebaseKey: String, kind: String): String {
        val friendly = defaultDisplayLabel(firebaseKey, kind)
        val raw = label?.trim().orEmpty()
        if (raw.isEmpty() || raw == firebaseKey || raw.equals(firebaseKey, true)) return friendly
        return raw
    }

    private fun normalizeControlMode(mode: String?, kind: String): String {
        if (kind == "switch") return "toggle"
        if (mode == "push" || mode == "toggle") return mode
        if (kind == "motor" || kind == "alarm") return "push"
        return "toggle"
    }

    private fun isStandaloneAuxKey(key: String): Boolean =
        key.endsWith(DbPaths.ON_TIMING_SUFFIX) ||
            key.endsWith(DbPaths.OFF_TIMING_SUFFIX) ||
            key.endsWith(DbPaths.PUSH_SUFFIX)

    private fun inferKind(key: String): String = when {
        key.endsWith(DbPaths.ON_TIMING_SUFFIX) -> "timing-on"
        key.endsWith(DbPaths.OFF_TIMING_SUFFIX) -> "timing-off"
        key.startsWith(DbPaths.SWITCH_PREFIX) -> "switch"
        key.startsWith(DbPaths.MOTOR_PREFIX) ->
            if (key.endsWith(DbPaths.PUSH_SUFFIX)) "motor-push" else "motor"
        key.startsWith(DbPaths.ALARM_PREFIX) || key.startsWith("ALRM") ->
            if (key.endsWith(DbPaths.PUSH_SUFFIX)) "alarm-push" else "alarm"
        else -> "switch"
    }

    fun roomAbbr(name: String): String {
        val parts = name.trim().split(Regex("\\s+"))
        return if (parts.size >= 2) {
            "${parts[0].first()}${parts[1].first()}".uppercase()
        } else {
            name.take(2).uppercase()
        }
    }

    fun findRoom(layout: HomeLayout, roomType: String, roomId: String): RoomEntry? =
        layout.roomsForType(roomType).find { it.id == roomId }

    fun availableKeys(layout: HomeLayout, roomType: String): List<CatalogItem> {
        val used = layout.roomsForType(roomType)
            .flatMap { it.devices }
            .map { it.firebaseKey }
            .toSet()
        return FirebaseCatalog.addableCatalog(roomType).filter { it.key !in used }
    }

    fun addRoom(layout: HomeLayout, roomType: String, name: String): Pair<RoomEntry?, String?> {
        val rooms = layout.roomsForType(roomType)
        if (rooms.size >= MAX_ROOMS_PER_TYPE) {
            return null to "Limit reached: max ${MAX_ROOMS_PER_TYPE - 1} additional rooms."
        }
        val room = RoomEntry(uid(), name.trim().ifEmpty { "New Room" })
        rooms.add(room)
        return room to null
    }

    fun removeRoom(layout: HomeLayout, roomType: String, roomId: String): String? {
        val rooms = layout.roomsForType(roomType)
        if (rooms.size <= 1) return "Keep at least one room in this category."
        rooms.removeAll { it.id == roomId }
        return null
    }

    fun renameRoom(layout: HomeLayout, roomType: String, roomId: String, name: String) {
        findRoom(layout, roomType, roomId)?.name = name.trim().ifEmpty {
            findRoom(layout, roomType, roomId)?.name.orEmpty()
        }
    }

    fun renameDevice(layout: HomeLayout, roomType: String, roomId: String, firebaseKey: String, label: String) {
        findRoom(layout, roomType, roomId)?.devices
            ?.find { it.firebaseKey == firebaseKey }
            ?.let { it.label = label.trim().ifEmpty { it.label } }
    }

    fun addDevice(
        layout: HomeLayout,
        roomType: String,
        roomId: String,
        firebaseKey: String,
        controlMode: String
    ): Boolean {
        val room = findRoom(layout, roomType, roomId) ?: return false
        val meta = FirebaseCatalog.addableCatalog(roomType).find { it.key == firebaseKey } ?: return false
        if (room.devices.any { it.firebaseKey == firebaseKey }) return false
        val mode = if (roomType == "switch") "toggle" else controlMode
        room.devices.add(
            DeviceEntry(meta.key, meta.defaultLabel, meta.kind, mode)
        )
        return true
    }

    fun removeDevice(layout: HomeLayout, roomType: String, roomId: String, firebaseKey: String) {
        findRoom(layout, roomType, roomId)?.devices?.removeAll { it.firebaseKey == firebaseKey }
    }

    fun countRoomActive(room: RoomEntry, values: Map<String, Any?>): Int =
        room.devices.count { device ->
            if (device.kind.startsWith("timing")) return@count false
            val key = if (FirebaseCatalog.usesPushControl(device)) {
                DbPaths.pushKeyFor(device.firebaseKey)
            } else {
                device.firebaseKey
            }
            val root = metaForKey(device.firebaseKey)?.root ?: DbPaths.rootForKey(device.firebaseKey)
            val path = root?.let { DbPaths.refPath(it, key) } ?: return@count false
            FirebaseValueUtils.isOn(values[path])
        }

    private fun uid() = "id-${System.currentTimeMillis()}-${UUID.randomUUID().toString().take(6)}"

    fun toFirebaseMap(layout: HomeLayout): Map<String, Any?> = mapOf(
        "version" to 4,
        "updatedAt" to System.currentTimeMillis(),
        "switchRooms" to layout.switchRooms.map { roomToMap(it) },
        "motorRooms" to layout.motorRooms.map { roomToMap(it) },
        "alarmRooms" to layout.alarmRooms.map { roomToMap(it) }
    )

    private fun roomToMap(room: RoomEntry): Map<String, Any?> = mapOf(
        "id" to room.id,
        "name" to room.name,
        "devices" to room.devices.map { device ->
            mapOf(
                "firebaseKey" to device.firebaseKey,
                "label" to device.label,
                "kind" to device.kind,
                "controlMode" to device.controlMode
            )
        }
    )
}
