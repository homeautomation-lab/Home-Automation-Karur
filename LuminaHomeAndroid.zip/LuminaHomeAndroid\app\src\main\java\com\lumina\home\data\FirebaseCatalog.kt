package com.lumina.home.data

import com.lumina.home.data.model.DeviceEntry

data class CatalogItem(
    val key: String,
    val root: String,
    val kind: String,
    val defaultLabel: String
)

object FirebaseCatalog {
    fun defaultDisplayLabel(firebaseKey: String, kind: String): String {
        return when {
            kind == "switch" || firebaseKey.startsWith(DbPaths.SWITCH_PREFIX) -> {
                val n = channelNumber(firebaseKey, DbPaths.SWITCH_PREFIX)
                if (n != null) "Switch $n" else firebaseKey
            }
            kind == "motor" || firebaseKey.startsWith(DbPaths.MOTOR_PREFIX) -> {
                val n = channelNumber(firebaseKey, DbPaths.MOTOR_PREFIX)
                if (n != null) "Motor $n" else firebaseKey
            }
            kind == "alarm" || firebaseKey.startsWith(DbPaths.ALARM_PREFIX) ||
                firebaseKey.startsWith("ALRM") -> {
                var n = channelNumber(firebaseKey, DbPaths.ALARM_PREFIX)
                if (n == null && firebaseKey.startsWith("ALRM")) {
                    n = channelNumber(firebaseKey, "ALRM")
                }
                if (n != null) "Alarm $n" else firebaseKey
            }
            else -> firebaseKey
        }
    }

    fun addableCatalog(roomType: String): List<CatalogItem> = when (roomType) {
        "switch" -> DbPaths.switchToggles().map {
            CatalogItem(it, DbPaths.SWITCH_ROOT, "switch", defaultDisplayLabel(it, "switch"))
        }
        "motor" -> DbPaths.motorToggles().map {
            CatalogItem(it, DbPaths.MOTOR_ROOT, "motor", defaultDisplayLabel(it, "motor"))
        }
        else -> DbPaths.alarmToggles().map {
            CatalogItem(it, DbPaths.ALARM_ROOT, "alarm", defaultDisplayLabel(it, "alarm"))
        }
    }

    fun metaForKey(firebaseKey: String): CatalogItem? {
        val all = addableCatalog("switch") + addableCatalog("motor") + addableCatalog("alarm")
        return all.find { it.key == firebaseKey }
    }

    fun hasBuiltInSchedule(kind: String) = kind == "switch" || kind == "motor"

    fun usesPushControl(device: DeviceEntry) = device.controlMode == "push"

    fun canChooseControlMode(roomType: String) = roomType == "motor" || roomType == "alarm"

    private fun channelNumber(key: String, prefix: String): String? {
        if (!key.startsWith(prefix)) return null
        val m = Regex("""^(\d+)""").find(key.removePrefix(prefix)) ?: return null
        return m.groupValues[1]
    }
}
