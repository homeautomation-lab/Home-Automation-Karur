# Lumina Home — Android Studio Project

Native Android app for the **Home Automation Karur** (Lumina/OS) Firebase Realtime Database console.

Package name: `com.lumina.home`  
Firebase project: `home-automation-009`  
Min Android: **API 26** (Android 8.0)  
Target SDK: **35**

## Firebase paths (unchanged from web app)

| Purpose | RTDB node |
|---------|-----------|
| Lights / switches | `SWITCH_CONTROL` (`SW1`…`SW40`, schedules `SW1-ON_TIMING`, etc.) |
| Motors / pumps | `MOTOR_CONTROL` (`M1`…`M10`, `-PUSH`, timings) |
| Alarms | `ALARM_CONTROLS` (`alarm1`…`alarm10`, `-PUSH`) |
| Room layout | `HOME_CONSOLE_LAYOUT` (version 4 JSON) |

Toggle values: `"0"` / `"1"`. Schedules: 24h `"HH:mm"`.

---

## 1. Open in Android Studio

1. Unzip `LuminaHomeAndroid.zip`.
2. **File → Open** → select the `LuminaHomeAndroid` folder.
3. Wait for Gradle sync (Android Studio downloads SDK/dependencies on first open).

## 2. Add `google-services.json` (required)

1. [Firebase Console](https://console.firebase.google.com/) → project **home-automation-009**.
2. **Project settings** → **Your apps** → **Add app** → **Android**.
3. Package name: **`com.lumina.home`** (must match exactly).
4. Download **`google-services.json`**.
5. Replace:

   `app/google-services.json`

   (Delete the placeholder file and paste your real one.)

6. **Sync Project with Gradle Files**.

### SHA-1 for Firebase (release / Play Store)

For Google Sign-In or some Firebase features you may need SHA-1:

**Debug keystore (default):**

```bash
keytool -list -v -keystore "%USERPROFILE%\.android\debug.keystore" -alias androiddebugkey -storepass android -keypass android
```

**Release keystore (after you create one):**

```bash
keytool -list -v -keystore your-release.keystore -alias your-alias
```

Add SHA-1 and SHA-256 in Firebase Console → Project settings → Your Android app → **Add fingerprint**.

### Realtime Database rules

Ensure your rules allow the app to read/write (same as web):

- `SWITCH_CONTROL`
- `MOTOR_CONTROL`
- `ALARM_CONTROLS`
- `HOME_CONSOLE_LAYOUT`

The web app uses no Firebase Auth; mobile works the same way.

---

## 3. Build APK

### Debug APK (quick test)

- **Build → Build Bundle(s) / APK(s) → Build APK(s)**
- Or terminal:

```bash
./gradlew assembleDebug
```

Output:

`app/build/outputs/apk/debug/app-debug.apk`

### Release APK (signed)

1. **Build → Generate Signed Bundle / APK** → **APK**.
2. Create or choose a keystore, set alias/password.
3. Select **release** build variant.
4. Output:

`app/build/outputs/apk/release/app-release.apk`

Or:

```bash
./gradlew assembleRelease
```

(Configure signing in `app/build.gradle.kts` with `signingConfigs` for CI.)

---

## 4. Install on phone

1. Enable **Install unknown apps** (or use USB debugging).
2. Copy `app-debug.apk` or `app-release.apk` to the device.
3. Open the APK and install.

Or: **Run** (green play) with USB debugging enabled.

---

## 5. Features

- Home overview with room cards (switches, motors, alarms)
- Room detail: toggles, push buttons, ON/OFF schedules
- Real-time Firebase sync (listeners + offline persistence)
- Layout sync to `HOME_CONSOLE_LAYOUT`
- Portrait-only, Material dark UI (white / gray / blue accents)

---

## Project structure

```
LuminaHomeAndroid/
├── app/
│   ├── google-services.json      ← replace with yours
│   ├── src/main/
│   │   ├── AndroidManifest.xml
│   │   └── java/com/lumina/home/
│   └── build.gradle.kts
├── build.gradle.kts
├── settings.gradle.kts
└── README.md
```

---

## Troubleshooting

| Issue | Fix |
|-------|-----|
| Gradle sync fails on `google-services.json` | Add valid file from Firebase for `com.lumina.home` |
| No data / permission denied | Check RTDB rules and `databaseURL` in Firebase project |
| Layout not saving | Allow write on `HOME_CONSOLE_LAYOUT` |
| Build needs SDK 35 | Install **Android SDK 35** in SDK Manager |

---

## Support

Built from the **Home-Automation-Karur** web console. All Firebase keys and behavior match the production web app.
