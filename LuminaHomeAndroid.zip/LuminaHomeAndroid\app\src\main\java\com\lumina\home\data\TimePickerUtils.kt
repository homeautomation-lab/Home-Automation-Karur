package com.lumina.home.data

data class ClockTime(val hour12: Int, val minute: Int, val am: Boolean)

object TimePickerUtils {
    fun parseTimeValue(raw: Any?): ClockTime {
        if (raw == null) return ClockTime(7, 0, true)
        val s = raw.toString().trim()
        if (s.isEmpty()) return ClockTime(7, 0, true)

        val ampm = Regex("""(\d{1,2}):(\d{2})\s*(AM|PM)""", RegexOption.IGNORE_CASE).find(s)
        if (ampm != null) {
            var h = ampm.groupValues[1].toInt()
            val m = ampm.groupValues[2].toInt()
            val pm = ampm.groupValues[3].equals("PM", true)
            if (h == 12) h = if (pm) 12 else 0 else if (pm) h += 12
            return from24(h % 24, m)
        }

        val hm = Regex("""^(\d{1,2}):(\d{2})$""").find(s)
        if (hm != null) return from24(hm.groupValues[1].toInt() % 24, hm.groupValues[2].toInt())

        val n = s.toIntOrNull()
        if (n != null && n in 0 until 1440) return from24(n / 60 % 24, n % 60)

        return ClockTime(7, 0, true)
    }

    fun formatTimeValue(time: ClockTime): String {
        val h24 = to24(time.hour12, time.am)
        return "%02d:%02d".format(h24, time.minute)
    }

    fun formatTimeDisplay(time: ClockTime): String {
        val suffix = if (time.am) "AM" else "PM"
        return "${time.hour12}:${time.minute.toString().padStart(2, '0')} $suffix"
    }

    fun formatTimeDisplay(raw: Any?): String {
        if (raw == null || raw.toString().trim().isEmpty()) return "Not set"
        return formatTimeDisplay(parseTimeValue(raw))
    }

    private fun from24(h24: Int, minute: Int): ClockTime {
        val am = h24 < 12
        var hour12 = h24 % 12
        if (hour12 == 0) hour12 = 12
        return ClockTime(hour12, minute, am)
    }

    private fun to24(hour12: Int, am: Boolean): Int =
        if (am) if (hour12 == 12) 0 else hour12
        else if (hour12 == 12) 12 else hour12 + 12
}
