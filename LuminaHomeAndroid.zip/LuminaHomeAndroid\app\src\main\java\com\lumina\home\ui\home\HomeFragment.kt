package com.lumina.home.ui.home

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.fragment.app.activityViewModels
import androidx.navigation.fragment.findNavController
import com.google.android.material.snackbar.Snackbar
import com.lumina.home.R
import com.lumina.home.databinding.FragmentHomeBinding
import com.lumina.home.ui.adapter.ZoneAdapter
import com.lumina.home.viewmodel.HomeViewModel

class HomeFragment : Fragment() {
    private var _binding: FragmentHomeBinding? = null
    private val binding get() = _binding!!
    private val vm: HomeViewModel by activityViewModels()
    private lateinit var zoneAdapter: ZoneAdapter

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View {
        _binding = FragmentHomeBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        zoneAdapter = ZoneAdapter { roomType, roomId ->
            vm.openRoom(roomType, roomId)
            val args = Bundle().apply {
                putString("roomType", roomType)
                putString("roomId", roomId)
            }
            findNavController().navigate(R.id.action_home_to_room, args)
        }
        binding.zoneList.adapter = zoneAdapter

        vm.zones.observe(viewLifecycleOwner) { zoneAdapter.submitZones(it) }
        vm.activeSummary.observe(viewLifecycleOwner) { binding.activeSummary.text = it }
        vm.connected.observe(viewLifecycleOwner) {
            binding.connectionStatus.text = if (it) "System Online" else "Connecting…"
        }
        vm.layoutSync.observe(viewLifecycleOwner) { status ->
            binding.syncBanner.visibility = if (status == null) View.GONE else View.VISIBLE
            binding.syncBanner.text = when (status) {
                "saving" -> "Saving layout to Firebase…"
                "saved" -> "Layout saved permanently"
                "error" -> "Could not save layout — check Firebase rules"
                else -> ""
            }
        }
        vm.toast.observe(viewLifecycleOwner) { msg ->
            msg?.let {
                Snackbar.make(binding.root, it, Snackbar.LENGTH_LONG).show()
                vm.clearToast()
            }
        }
        vm.error.observe(viewLifecycleOwner) { err ->
            err?.let { Snackbar.make(binding.root, it, Snackbar.LENGTH_LONG).show() }
        }
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}
