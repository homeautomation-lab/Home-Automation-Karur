package com.lumina.home.data.model

data class DeviceEntry(
    val firebaseKey: String,
    var label: String,
    val kind: String,
    val controlMode: String = "toggle"
)

data class RoomEntry(
    val id: String,
    var name: String,
    val devices: MutableList<DeviceEntry> = mutableListOf()
)

data class HomeLayout(
    val switchRooms: MutableList<RoomEntry> = mutableListOf(),
    val motorRooms: MutableList<RoomEntry> = mutableListOf(),
    val alarmRooms: MutableList<RoomEntry> = mutableListOf()
) {
    fun roomsForType(roomType: String): MutableList<RoomEntry> = when (roomType) {
        "switch" -> switchRooms
        "motor" -> motorRooms
        else -> alarmRooms
    }
}

data class ZoneSection(
    val roomType: String,
    val title: String,
    val rooms: List<RoomCardUi>
)

data class RoomCardUi(
    val roomType: String,
    val roomId: String,
    val name: String,
    val abbr: String,
    val deviceCount: Int,
    val activeCount: Int,
    val hasActive: Boolean
)

data class DeviceRowUi(
    val firebaseKey: String,
    val label: String,
    val kind: String,
    val controlMode: String,
    val root: String,
    val isOn: Boolean,
    val isPush: Boolean,
    val hasSchedule: Boolean,
    val onTimeDisplay: String,
    val offTimeDisplay: String,
    val onTimePath: String,
    val offTimePath: String
)
