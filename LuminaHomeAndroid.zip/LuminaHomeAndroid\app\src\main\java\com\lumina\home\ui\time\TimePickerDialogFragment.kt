package com.lumina.home.ui.time

import android.app.Dialog
import android.os.Bundle
import android.view.LayoutInflater
import android.widget.NumberPicker
import androidx.appcompat.app.AlertDialog
import androidx.fragment.app.DialogFragment
import com.lumina.home.R
import com.lumina.home.data.ClockTime
import com.lumina.home.data.TimePickerUtils

class TimePickerDialogFragment : DialogFragment() {
    interface Listener {
        fun onTimeSaved(path: String, formatted: String)
        fun onTimeCleared(path: String)
    }

    override fun onCreateDialog(savedInstanceState: Bundle?): Dialog {
        val path = requireArguments().getString(ARG_PATH).orEmpty()
        val label = requireArguments().getString(ARG_LABEL).orEmpty()
        val isOn = requireArguments().getBoolean(ARG_IS_ON)
        val raw = requireArguments().getString(ARG_RAW)
        val time = TimePickerUtils.parseTimeValue(raw)

        val view = LayoutInflater.from(requireContext()).inflate(R.layout.dialog_time_picker, null)
        val hourPicker = view.findViewById<NumberPicker>(R.id.hourPicker)
        val minutePicker = view.findViewById<NumberPicker>(R.id.minutePicker)
        val ampmPicker = view.findViewById<NumberPicker>(R.id.ampmPicker)

        hourPicker.minValue = 1
        hourPicker.maxValue = 12
        hourPicker.value = time.hour12

        minutePicker.minValue = 0
        minutePicker.maxValue = 59
        minutePicker.value = time.minute

        ampmPicker.minValue = 0
        ampmPicker.maxValue = 1
        ampmPicker.displayedValues = arrayOf("AM", "PM")
        ampmPicker.value = if (time.am) 0 else 1

        val title = if (isOn) "Set ON time" else "Set OFF time"

        return AlertDialog.Builder(requireContext())
            .setTitle("$title — $label")
            .setView(view)
            .setPositiveButton(R.string.save) { _, _ ->
                val clock = ClockTime(
                    hourPicker.value,
                    minutePicker.value,
                    ampmPicker.value == 0
                )
                (parentFragment as? Listener ?: activity as? Listener)
                    ?.onTimeSaved(path, TimePickerUtils.formatTimeValue(clock))
            }
            .setNeutralButton(R.string.clear) { _, _ ->
                (parentFragment as? Listener ?: activity as? Listener)?.onTimeCleared(path)
            }
            .setNegativeButton(android.R.string.cancel, null)
            .create()
    }

    companion object {
        private const val ARG_PATH = "path"
        private const val ARG_LABEL = "label"
        private const val ARG_IS_ON = "isOn"
        private const val ARG_RAW = "raw"

        fun newInstance(path: String, label: String, isOn: Boolean, raw: String?) =
            TimePickerDialogFragment().apply {
                arguments = Bundle().apply {
                    putString(ARG_PATH, path)
                    putString(ARG_LABEL, label)
                    putBoolean(ARG_IS_ON, isOn)
                    putString(ARG_RAW, raw)
                }
            }
    }
}
