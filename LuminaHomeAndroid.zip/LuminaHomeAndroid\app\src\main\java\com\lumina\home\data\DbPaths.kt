package com.lumina.home.data

object DbPaths {
    const val SWITCH_ROOT = "SWITCH_CONTROL"
    const val MOTOR_ROOT = "MOTOR_CONTROL"
    const val ALARM_ROOT = "ALARM_CONTROLS"
    const val LAYOUT_ROOT = "HOME_CONSOLE_LAYOUT"

    const val SWITCH_COUNT = 40
    const val MOTOR_COUNT = 10
    const val ALARM_COUNT = 10

    const val SWITCH_PREFIX = "SW"
    const val MOTOR_PREFIX = "M"
    const val ALARM_PREFIX = "alarm"
    const val ON_TIMING_SUFFIX = "-ON_TIMING"
    const val OFF_TIMING_SUFFIX = "-OFF_TIMING"
    const val PUSH_SUFFIX = "-PUSH"

    fun refPath(root: String, key: String) = "$root/$key"

    val controlRoots = listOf(SWITCH_ROOT, MOTOR_ROOT, ALARM_ROOT)

    fun switchToggles(): List<String> = numList(SWITCH_PREFIX, SWITCH_COUNT)
    fun motorToggles(): List<String> = numList(MOTOR_PREFIX, MOTOR_COUNT)
    fun alarmToggles(): List<String> = numList(ALARM_PREFIX, ALARM_COUNT)

    fun timingPaths(prefix: String, count: Int): List<String> {
        val keys = mutableListOf<String>()
        for (i in 1..count) {
            keys += "${prefix}$i$ON_TIMING_SUFFIX"
            keys += "${prefix}$i$OFF_TIMING_SUFFIX"
        }
        return keys
    }

    fun pushPaths(prefix: String, count: Int): List<String> =
        (1..count).map { "${prefix}$it$PUSH_SUFFIX" }

    private fun numList(prefix: String, count: Int): List<String> =
        (1..count).map { "$prefix$it" }

    fun timingPathsFor(baseKey: String): Pair<String, String> =
        "${baseKey}$ON_TIMING_SUFFIX" to "${baseKey}$OFF_TIMING_SUFFIX"

    fun pushKeyFor(baseKey: String): String = "$baseKey$PUSH_SUFFIX"

    fun rootForKey(key: String): String? = when {
        key.startsWith(SWITCH_PREFIX) -> SWITCH_ROOT
        key.startsWith(MOTOR_PREFIX) -> MOTOR_ROOT
        key.startsWith(ALARM_PREFIX) || key.startsWith("ALRM") -> ALARM_ROOT
        else -> null
    }
}
