package com.lumina.home.ui.adapter

import android.annotation.SuppressLint
import android.view.LayoutInflater
import android.view.MotionEvent
import android.view.ViewGroup
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import com.lumina.home.data.DbPaths
import com.lumina.home.data.model.DeviceRowUi
import com.lumina.home.databinding.ItemDeviceRowBinding

class DeviceAdapter(
    private val onToggle: (String, String) -> Unit,
    private val onPush: (String, String, Boolean) -> Unit,
    private val onTimeClick: (DeviceRowUi, Boolean) -> Unit,
    private val onRename: (DeviceRowUi) -> Unit,
    private val onRemove: (DeviceRowUi) -> Unit
) : ListAdapter<DeviceRowUi, DeviceAdapter.VH>(Diff) {

    class VH(val binding: ItemDeviceRowBinding) : RecyclerView.ViewHolder(binding.root)

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH {
        val binding = ItemDeviceRowBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return VH(binding)
    }

    @SuppressLint("ClickableViewAccessibility")
    override fun onBindViewHolder(holder: VH, position: Int) {
        val item = getItem(position)
        val b = holder.binding
        b.deviceLabel.text = item.label
        b.deviceKey.text = item.firebaseKey
        b.deviceRow.isActivated = item.isOn

        if (item.isPush) {
            b.toggleSwitch.visibility = android.view.View.GONE
            b.pushButton.visibility = android.view.View.VISIBLE
            b.pushButton.isPressed = item.isOn
            b.pushButton.setOnTouchListener { _, event ->
                when (event.actionMasked) {
                    MotionEvent.ACTION_DOWN -> {
                        onPush(item.root, DbPaths.pushKeyFor(item.firebaseKey), true)
                        true
                    }
                    MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                        onPush(item.root, DbPaths.pushKeyFor(item.firebaseKey), false)
                        true
                    }
                    else -> false
                }
            }
        } else {
            b.pushButton.visibility = android.view.View.GONE
            b.toggleSwitch.visibility = android.view.View.VISIBLE
            b.toggleSwitch.setOnCheckedChangeListener(null)
            b.toggleSwitch.isChecked = item.isOn
            b.toggleSwitch.setOnCheckedChangeListener { _, _ ->
                onToggle(item.root, item.firebaseKey)
            }
        }

        if (item.hasSchedule) {
            b.scheduleRow.visibility = android.view.View.VISIBLE
            b.onTimeBtn.text = "ON ${item.onTimeDisplay}"
            b.offTimeBtn.text = "OFF ${item.offTimeDisplay}"
            b.onTimeBtn.setOnClickListener { onTimeClick(item, true) }
            b.offTimeBtn.setOnClickListener { onTimeClick(item, false) }
        } else {
            b.scheduleRow.visibility = android.view.View.GONE
        }

        b.renameBtn.setOnClickListener { onRename(item) }
        b.removeBtn.setOnClickListener { onRemove(item) }
    }

    private object Diff : DiffUtil.ItemCallback<DeviceRowUi>() {
        override fun areItemsTheSame(a: DeviceRowUi, b: DeviceRowUi) = a.firebaseKey == b.firebaseKey
        override fun areContentsTheSame(a: DeviceRowUi, b: DeviceRowUi) = a == b
    }
}
